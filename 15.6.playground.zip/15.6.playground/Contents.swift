import UIKit
//1. Создайте перечисление для ошибок. Добавьте в него 3 кейса:
//
//ошибка 400,
//ошибка 404,
//ошибка 500.
//Далее создайте переменную, которая будет хранить в себе какую-либо ошибку (400 или 404 или 500). И при помощи do-catch сделайте обработку ошибок перечисления. Для каждой ошибки должно быть выведено сообщение в консоль.
//2. Теперь добавьте проверку переменных в генерирующую функцию и обрабатывайте её!
//3. Напишите функцию, которая будет принимать на вход два разных типа и проверять: если типы входных значений одинаковые, то вывести сообщение “Yes”, в противном случае — “No”.
//4. Реализуйте то же самое, но если тип входных значений различается, выбросите исключение. Если тип одинаковый — тоже выбросите исключение, но оно уже будет говорить о том, что типы одинаковые. Не бойтесь этого. Ошибки — это не всегда про плохой результат.
//5. Напишите функцию, которая принимает на вход два любых значения и сравнивает их при помощи оператора равенства ==.



//------------------------------------------------------------------------------------
//1. Создано перечисление, которое соответствует протоколу Error. Для него создано любые 3 кейса —  ошибки. Есть переменная, которая хранит в себе ошибку (400 или 404 или 500). Есть обработка ошибок перечисления при помощи do-catch. Для каждой ошибки выведено сообщение в консоль.

 enum Oshibki: Error {
    case notFound // 404 Not Found («не найдено»)
    case badRequest  // 400 Bad Request («неправильный, некорректный запрос»)
    case internalServerError // 500 Internal Server Error («внутренняя ошибка сервера»)
}

var notFound: Bool = false
var badRequest: Bool = false
var internalServerError: Bool = true

do {
    if notFound {
        throw Oshibki.notFound
    }

    if badRequest {
        throw Oshibki.badRequest
    }

    if internalServerError {
        throw Oshibki.internalServerError
    }
    
} catch Oshibki.notFound {
    print("404 Not Found")
} catch Oshibki.badRequest {
    print("400 Bad Request")
} catch Oshibki.internalServerError {
    print("500 Internal Server Error")
}
//------------------------------------------------------------------------------------
//2. Есть проверка переменных в генерирующей функцию, есть её обработка.

var isNotFound = false
var isBadRequest = false
var isinternalServerError = false

func proverkaOshibok() throws {
    if isNotFound {
        throw Oshibki.notFound
    }
    if isBadRequest {
        Oshibki.badRequest
    }
    if isinternalServerError {
        Oshibki.internalServerError
    }
}
isNotFound = true

do {
    try proverkaOshibok()
} catch Oshibki.notFound {
    print("404 Not Found")
} catch Oshibki.badRequest {
    print("400 Bad Request")
} catch Oshibki.internalServerError {
    print("500 Internal Server Error")
}
 
//------------------------------------------------------------------------------------
//3. Есть функция, принимающая на вход два разных типа, которая проверяет типы входных значений. Выводит “Yes”, если они одинаковые, в противном случае — “No”.

func someFunc<T: Equatable, E: Equatable>(a: T, b: E) {
    if type(of: a) == type(of: b) {
     if let b = b as? T {
      if a == b {
       print("YES")
       return
      }
     }
    }
    print("NO")
   }
someFunc(a: "s", b: "s")
someFunc(a: 3, b: 7)
someFunc(a: "J", b: 4)
someFunc(a: 5, b: 5)

//------------------------------------------------------------------------------------
//4. Реализовано то же самое, что и в пункте 3, но если тип входных значений различается, выбрасывается исключение. Если тип одинаковый — исключение тоже выбрасывается.
enum Oshibki2: Error {
    case differentTypes //differentTypes («разные типы»)
    case identicalTypes //identicalTypes («одинаковые типы»)
}
func someFunc1<U: Equatable, D: Equatable>(a: U, b: D) throws {
    if type(of: a) == type(of: b) {
     if let b = b as? U {
        if a == b { do {
            throw Oshibki2.identicalTypes
        }
        }
     }
        else { do {
            throw Oshibki2.differentTypes
        }
        }
    }
}

try? someFunc1(a: "s", b: "s")
try? someFunc1(a: 3, b: 7)
try? someFunc1(a: "J", b: 4)
try? someFunc1(a: 5, b: 5)


//------------------------------------------------------------------------------------
//5. Есть функция, которая принимает на вход два любых значения и сравнивает их при помощи оператора равенства (==).

func equal<T: Equatable>(_ a: T, _ b: T) -> Bool {
    return a == b
}

print(equal(10, 1))
//------------------------------------------------------------------------------------

